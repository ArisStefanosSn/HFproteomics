hf_net1<-read.table("~/Desktop/CytoscapeInput_HF_edges_blue.txt",sep="\t",header=T)
targets<-c("B2M","CST3","TNFRSF1B","TNFRSF1A","EPHA2","EFNA4","EFNA5",
            "IL15RA","CD59","IGFBP6","JAM2","RELT","TFF3","DSC2")
mm1<-which(match(as.character(hf_net1[,1]),targets,nomatch=0)>0)
mm2<-which(match(as.character(hf_net1[,2]),targets,nomatch=0)>0)
mm<-unique(c(mm1,mm2))
hf_net1<-hf_net1[mm,]
hf_net1a<-hf_net1[as.numeric(as.character(hf_net1[,3]))>0.2,]
#hf_net1b<-hf_net1[as.numeric(as.character(hf_net1[,3]))>0.15 & as.character(hf_net1[,1])=="IGFBP2" |
           # as.numeric(as.character(hf_net1[,3]))>0.15 & as.character(hf_net1[,2])=="IGFBP2" |
            #,]
#cc<-colnames(hf_net1a)
#hf_net1<-as.matrix(rbind(hf_net1a,hf_net1b))
hf_net1<-hf_net1a
for(i in 1:nrow(hf_net1)){
    mm<-match(targets,c(as.character(hf_net1[i,1]),as.character(hf_net1[i,2])),nomatch=0)
    mm<-mm[mm>0]
    if(mm[1]==2 & length(mm)==1){
        hf_net1[i,1:2]<-hf_net1[i,2:1]
        hf_net1[i,5:6]<-hf_net1[i,6:5]
    }
}
dim(hf_net1)
write.table(hf_net1,"~/Desktop/net1.txt",sep="\t",row.names=F,quote=F)



# check the connctions at control and add a column to separate the connections that remained from those that were severed
control_net1<-read.table("~/Desktop/CytoscapeInput_Control_edges_grey.txt",sep="\t",header=T)
control_net2<-read.table("~/Desktop/CytoscapeInput_Control_edges_turquoise.txt",sep="\t",header=T)
control_net<-as.matrix(rbind(control_net1,control_net2))
mm1<-which(match(as.character(control_net[,1]),targets,nomatch=0)>0)
mm2<-which(match(as.character(control_net[,2]),targets,nomatch=0)>0)
mm<-unique(c(mm1,mm2))
control_net<-control_net[mm,]
control_netA<-control_net[as.numeric(as.character(control_net[,3]))>0.11,]
cc<-colnames(control_netA)
control_net<-control_netA
length(unique(c(control_net[,1],control_net[,2])))
write.table(control_net,"~/Desktop/net2.txt",sep="\t",row.names=F,quote=F)



control_net1<-read.table(paste(dataOutput,"CytoscapeInput_Control_edges_grey.txt",sep=""),sep="\t",header=T)
control_net2<-read.table(paste(dataOutput,"CytoscapeInput_Control_edges_turquoise.txt",sep=""),sep="\t",header=T)
control_net<-as.matrix(rbind(control_net1,control_net2))
mm1<-which(match(as.character(control_net[,1]),targets,nomatch=0)>0)
mm2<-which(match(as.character(control_net[,2]),targets,nomatch=0)>0)
mm<-unique(c(mm1,mm2))
control_net<-control_net[mm,]

pass<-cbind(rep(0,nrow(hf_net1)),rep("N",nrow(hf_net1)))
for(i in 1:nrow(hf_net1)){
    w<-which(control_net[,1]==hf_net1[i,1] & control_net[,2]==hf_net1[i,2] |
                control_net[,2]==hf_net1[i,1] & control_net[,1]==hf_net1[i,2])
    if(length(w)){
        pass[i,1]<-as.numeric(as.character(control_net[w,3]))
        if(pass[i,1]>=(0.33*as.numeric(as.character(hf_net1[i,3])))){
            pass[i,2]<-"Y"
        }
    }
}
hf_net1<-cbind(hf_net1,pass)
colnames(hf_net1)<-c(cc,"Regulator","Control_weight","Strong_in_Control")





hf_net1<-data.frame(hf_net1)

# the strongest connections compared to control
hf_net1[as.character(hf_net1$Strong_in_Control)=="N",]
