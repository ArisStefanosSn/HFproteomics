#############
# LIBRARIES #
#############

suppressMessages(library(Hmisc))
suppressMessages(library(limma))
suppressMessages(library(metaRNASeq))
suppressMessages(library(Rtsne))
suppressMessages(library(ggplot2))
suppressMessages(library(lawstat))
suppressMessages(library(gtools))
suppressMessages(library(superheat))
suppressMessages(library(stringr))
suppressMessages(library(WGCNA))
suppressMessages(library(gplots))
suppressMessages(library(plotly))
suppressMessages(library(scales))
suppressMessages(library(data.table))
suppressMessages(library(scater))
suppressMessages(library(scran))
suppressMessages(library(randomForest))
suppressMessages(library(splines))
suppressMessages(library(ggfortify))

#############
# FUNCTIONS #
#############

# Checks for NA entries in the variables
check_variables_for_NA<-function(data){
    w<-which(is.na(data)==TRUE,arr.ind=TRUE)
    rows<-as.numeric(w[,1])
    cols<-as.numeric(w[,2])
    type=c()
    if(length(cols)>0){
        for(i in 1:length(cols)){
            type[i]<-typeof(data[,cols[i]])
        }
    }
 return(list(rows,cols,type))
}


# manipulate gene / protein names
GeneNames<-function(data,k=2){
    ss<-strsplit(as.character(data), ":")
    res<-rep(0,length(ss))
    for(i in 1:length(ss)){
        res[i]<-ss[[i]][k]
    }
    return(res)
}


# Adjusts the CDCS data
adjustData_CDCS<-function(Expr,Design){
    
    Group<-factor(Design$Somalogic_Group_Summary)
    Group<-relevel(Group,ref="Control")
    Gender<-factor(Design$Gender)
    Age<-as.numeric(as.character(Design$Age))
    Ethnicity<-factor(Design$Race)
    Smoker<-factor(Design$Smoker)
    BMI<-as.numeric(as.character(Design$BMI))
    BMI[BMI=="---"]<-NA
    Diabetes<-factor(Design$History.of.diabetes)
    HTN<-as.character(Design$History.of.hypertension)
    HTN[HTN=="---"]<-NA
    HTN<-factor(HTN)
    HLP<-as.character(Design$History.of.hyperlipidemia)
    HLP[HLP=="---"]<-NA
    HLP<-factor(HLP)
    Renal<-as.character(Design$Hx_Renal)
    Renal[Renal=="---"]<-NA
    Renal<-factor(Renal)
    MI<-as.character(Design$Hx_MI)
    MI[MI=="---"]<-NA
    MI<-factor(MI)
    HF<-as.character(Design$Hx_HF)
    HF[HF=="---"]<-NA
    HF<-factor(HF)
    PTCA<-as.character(Design$Hx_PTCA)
    PTCA[PTCA=="---"]<-NA
    PTCA<-factor(PTCA)
    Diagnosis<-factor(Design$Diagnosis_Dx)
    Beta<-factor(Design$Beta_blocker_Discharge)
    ACE<-factor(Design$ACE1)
    Vessel<-as.character(Design$VesselDisease)
    Vessel[Vessel=="LM+Triple"]<-"Triple"
    Vessel<-factor(Vessel)
    
    fitted<-matrix(0,nrow(Expr),ncol(Expr))
    rownames(fitted)<-rownames(Expr)
    colnames(fitted)<-colnames(Expr)
    mydata<-data.frame(Group,Gender,Age,Ethnicity,Smoker,BMI,Diabetes,HTN,HLP,Renal,MI,HF,PTCA,Diagnosis,Beta,ACE,Vessel)
    rownames(mydata)<-colnames(Expr)
    check<-check_variables_for_NA(data=mydata)

    
    if(length(check[[1]])>0){
        impute_arg <- aregImpute(~ Group+Gender+Age+Ethnicity+Smoker+BMI+Diabetes+HTN+HLP+Renal+MI+HF+PTCA+Diagnosis+Beta+ACE+Vessel, data = mydata, n.impute = 10)
        for(i in 1:length(check[[1]])){
            a<-median(impute_arg$imputed[[check[[2]][i]]])
            if(check[[3]][i]=="integer"){
                a<-levels(mydata[,check[[2]][i]])[a]
            }
            mydata[check[[1]][i],check[[2]][i]]<-a
        }
    }
    
    for(i in 1:nrow(Expr)){
        mod<-lm(log(as.numeric(as.character(Expr[i,])),10)~
                    Age+Gender+Ethnicity+Smoker+BMI,data=mydata)
        average<-mod$coefficients[[1]]
        ff<-residuals(mod)
        fitted[i,]<-average+as.numeric(ff)
    }
    return(fitted)
}


# Adjusts the IMMACULATE data
adjustData_IMMACULATE<-function(Expr,Design){
    
    Group<-factor(Design$Somalogic_Group_Summary)
    Group<-relevel(Group,ref="Control")
    Age<-as.numeric(as.character(Design$Age))
    Ethnicity<-factor(Design$Race)
    Smoker<-factor(Design$Smoker)
    BMI<-as.numeric(as.character(Design$BMI))
    BMI[BMI=="---"]<-NA
    Diabetes<-as.character(Design$History.of.diabetes)
    Diabetes[Diabetes=="---"]<-NA
    Diabetes<-factor(Diabetes)
    HTN<-factor(Design$History.of.hypertension)
    HLP<-factor(Design$History.of.hyperlipidemia)
    MI<-factor(Design$Hx_MI)
    PTCA<-factor(Design$Hx_PTCA)
    Diagnosis<-factor(Design$Diagnosis_Dx)
    Vessel<-as.character(Design$VesselDisease)
    Vessel[Vessel=="LM+Triple"]<-"Triple"
    Vessel<-factor(Vessel)
    Batch<-factor(Design$Batch)
    
    fitted<-matrix(0,nrow(Expr),ncol(Expr))
    rownames(fitted)<-rownames(Expr)
    colnames(fitted)<-colnames(Expr)
    mydata<-data.frame(Group,Age,Ethnicity,Smoker,BMI,Diabetes,HTN,HLP,Diagnosis,Vessel)
    rownames(mydata)<-colnames(Expr)
    check<-check_variables_for_NA(data=mydata)
    
    
    if(length(check[[1]])>0){
        impute_arg <- aregImpute(~ Group+Age+Ethnicity+Smoker+BMI+Diabetes+HTN+HLP+Diagnosis+Vessel, data = mydata, n.impute = 10)
        for(i in 1:length(check[[1]])){
            a<-median(impute_arg$imputed[[check[[2]][i]]])
            if(check[[3]][i]=="integer"){
                a<-levels(mydata[,check[[2]][i]])[a]
            }
            mydata[check[[1]][i],check[[2]][i]]<-a
        }
    }
    
    for(i in 1:nrow(Expr)){
        mod<-lm(log(as.numeric(as.character(Expr[i,])),10)~
                    Age+Ethnicity+Smoker+BMI+Batch,data=mydata)
        average<-mod$coefficients[[1]]
        ff<-residuals(mod)
        fitted[i,]<-average+as.numeric(ff)
    }
    return(fitted)
}


# summmarise the information of CDCS
CDCS_summary<-function(folder){
    desi17259<-read.table(paste(folder,"Adjusted_Design_CDCS.txt",sep=""),sep="\t")
    fitted17259<-read.table(paste(folder,"Adjusted_Expression_CDCS.txt",sep=""),sep="\t")
    annot<-read.table(paste(folder,"Somalogic_Annotation_CDCS.txt",sep=""),sep="\t")
    d2<-read.table(paste(folder,"Somalogic_Design_CDCS.txt",sep=""),sep="\t")
    mm2<-match(rownames(desi17259),rownames(d2),nomatch=0)
    d2<-d2[mm2,]
    desi17259<-cbind(desi17259,d2[,53:54])
    w17259<-which(desi17259$Somalogic_Group_Full=="HF_and_MI_together" | desi17259$Somalogic_Group_Full=="HF_First" |
    desi17259$Somalogic_Group_Summary=="Control")
    fitted17259<-fitted17259[,w17259]
    desi17259<-desi17259[w17259,]
 return(list(Expr=fitted17259,Design=desi17259,Annotation=annot))
}

# summmarise the information of IMMACULATE
IMMACULATE_summary<-function(folder){
    desi17228<-read.table(paste(folder,"Adjusted_Design_IMMACULATE.txt",sep=""),sep="\t")
    fitted17228<-read.table(paste(folder,"Adjusted_Expression_IMMACULATE.txt",sep=""),sep="\t")
    annot<-read.table(paste(folder,"Somalogic_Annotation_IMMACULATE.txt",sep=""),sep="\t")
    d1<-read.table(paste(folder,"Somalogic_Design_IMMACULATE.txt",sep=""),sep="\t")
    mm1<-match(rownames(desi17228),rownames(d1),nomatch=0)
    d1<-d1[mm1,]
    desi17228<-cbind(desi17228,d1[,53:54])
    w17228<-which(desi17228$Somalogic_Group_Full=="ACS")
    fitted17228<-fitted17228[,w17228]
    desi17228<-data.frame(as.matrix(desi17228[w17228,]))
 return(list(Expr=fitted17228,Design=desi17228,Annotation=annot))
}


# differential expression analysis
DE_forHF<-function(Exprs,Design,Annotation,Cohort){
    Group<-factor(Design$HF)
    Group<-factor(as.character(Group))
    Group<-relevel(Group,ref="N")
    design <- model.matrix(~ 0 + Group)
    colnames(design)<-c("N","Y")
    fit <- lmFit(Exprs,design)
    contrast.matrix <- makeContrasts(Y-N, levels=design)
    fit2 <- contrasts.fit(fit, contrast.matrix)
    fit2 <- eBayes(fit2)
    HFyes_vs_HFno<-topTable(fit2,coef=1,adjust="BH",n=nrow(Exprs))
    HFyes_vs_HFno<-cbind(HFyes_vs_HFno,Comparison="HF-Control")
    DEs<-rbind(cbind(Protein = rownames(HFyes_vs_HFno),HFyes_vs_HFno))
    DEs$logFC<-log(10^as.numeric(as.character(DEs$logFC)),2)
    mm<-match(rownames(DEs),rownames(Annotation))
    Annotation<-Annotation[mm,]
    DEs<-cbind(Annotation,DEs)
    if(Cohort=="CDCS"){
        DEs<-DEs[,-c(8,14)]
    } else {
        DEs<-DEs[,-c(8,15)]
    }
 return(DEs)
}


# meta-analysis (cross-cohort validation)
metaCohorts<-function(DE_CDCS,DE_IMMACULATE){
    d1<-DE_CDCS[DE_CDCS$Flag=="PASS",]
    d2<-DE_IMMACULATE[DE_IMMACULATE$FlagA=="PASS",]
    ii<-intersect(as.character(rownames(d1)),as.character(rownames(d2)))
    d1<-d1[match(ii,as.character(rownames(d1))),]
    d2<-d2[match(ii,as.character(rownames(d2))),]
    logfcs<-list(CDCS_logFC=d1$logFC,IMM_logFC=d2$logFC)
    rawp<-list(CDCS_rawP=d1$P.Value,IMM_rawP=d2$P.Value)
    fdr<-list(CDCS_FDR=d1$adj.P.Val,IMM_FDR=d2$adj.P.Val)
    DEfdr5 <- mapply(fdr, FUN=function(x) ifelse(x <= 0.05, 1, 0))
    DErawp5 <- mapply(rawp, FUN=function(x) ifelse(x <= 0.05, 1, 0))
    signsFC <- mapply(logfcs, FUN=function(x) sign(x))
    sumsigns <- apply(signsFC,1,sum)
    commonsgnFC <- ifelse(abs(sumsigns)==dim(signsFC)[2], sign(sumsigns),0)
    fishcomb <- fishercomb(rawp, BHth = 0.05)
    dat1<-ifelse(DEfdr5[,1]==1,TRUE,FALSE)
    dat2<-ifelse(DErawp5[,1]==1,TRUE,FALSE)
    dat3<-ifelse(DEfdr5[,2]==1,TRUE,FALSE)
    dat4<-ifelse(DErawp5[,2]==1,TRUE,FALSE)
    DEresults <- data.frame(isDE_byFDR5perc_CDCS=dat1,isDE_byP5perc_CDCS=dat2,isDE_byFDR5perc_IMM=dat3,isDE_byP5perc_IMM=dat4,
                            signIndex=commonsgnFC,Fisher_meta_FDR=fishcomb$adjpval)
    rownames(DEresults)<-ii
    sel<-rep(FALSE,nrow(DEresults))
    sel[which(DEresults$signIndex!=0 & as.numeric(as.character(DEresults$Fisher_meta))<=0.05 & DEresults$isDE_byFDR5perc_CDCS==TRUE & DEresults$isDE_byP5perc_IMM==TRUE |
        DEresults$signIndex!=0 & as.numeric(as.character(DEresults$Fisher_meta))<=0.05 & DEresults$isDE_byFDR5perc_IMM==TRUE & DEresults$isDE_byP5perc_CDCS==TRUE)]<-TRUE
    DEresults<-cbind(DEresults,Validated=sel)
    DEresults<-DEresults[sort.list(DEresults$Validated,decreasing=T),]
 return(DEresults[,-2])
}



# Random forests test-prediction application
myRF<-function(Expr_CDCS,Expr_IMMACULATE,Design_CDCS,Design_IMMACULATE,proteins,ntree){
    
    pData36_IMMACULATE<-Expr_IMMACULATE[match(proteins,rownames(Expr_IMMACULATE)),]
    pData36_CDCS<-Expr_CDCS[match(proteins,rownames(Expr_CDCS)),]
    pData36_IMMACULATE<-data.frame(t(pData36_IMMACULATE-rowMeans(pData36_IMMACULATE)),HF=as.character(Design_IMMACULATE$HF),check.names=F)
    pData36_IMMACULATE$HF<-factor(pData36_IMMACULATE$HF)
    pData36_CDCS<-t(pData36_CDCS-rowMeans(pData36_CDCS))

    colnames(pData36_IMMACULATE)<-GeneNames(colnames(pData36_IMMACULATE),k=1)
    colnames(pData36_CDCS)<-GeneNames(colnames(pData36_CDCS),k=1)

    rf1<- randomForest(HF ~ ., data=pData36_IMMACULATE, importance=TRUE,proximity=TRUE,ntree=ntree)
    pred1 <- predict(rf1,pData36_CDCS)
    tt<-table(pred1,as.character(data_CDCS$Design$Somalogic_Group_Summary))
    di<-diag(tt)
    if(length(di)==1){
        confusion<-rep(-1,3)
    } else {
        confusion<-c(length(proteins),1-diag(tt)/apply(tt,1,sum))
    }
    
 return(confusion)
}


# assesing the HF vs Control separation by RF
rfGroupSeparation <- function(Expr_CDCS,Expr_IMMACULATE,Design_CDCS,Design_IMMACULATE,DEs_CDCS,DEs_IMMACULATE,proteins,ntree=1000,starting.fdr=0.05,ending.fdr=0.4,step=0.01){
    
    # original
    k <- myRF(Expr_CDCS=Expr_CDCS,Expr_IMMACULATE=Expr_IMMACULATE,Design_CDCS=Design_CDCS,Design_IMMACULATE=Design_IMMACULATE,proteins=proteins,ntree=ntree)
    
    # DE subsets
    steps<-seq(starting.fdr,stopping.fdr,step)
    de1<-DEs_CDCS[sort.list(as.numeric(as.character(DEs_CDCS$adj.P.Val))),]
    de2<-DEs_IMMACULATE[sort.list(as.numeric(as.character(DEs_IMMACULATE$adj.P.Val))),]
    de1<-de1[as.numeric(as.character(de1$adj.P.Val))<=stopping.fdr,]
    de2<-de2[as.numeric(as.character(de2$adj.P.Val))<=stopping.fdr,]
    
    for(i in 1:length(steps)){
        set1<-de1[as.numeric(as.character(de1$adj.P.Val))<=steps[i],]
        set2<-de2[as.numeric(as.character(de2$adj.P.Val))<=steps[i],]
        k <- rbind(k,myRF(Expr_CDCS=Expr_CDCS,Expr_IMMACULATE=Expr_IMMACULATE,Design_CDCS=Design_CDCS,Design_IMMACULATE=Design_IMMACULATE,proteins=intersect(rownames(set1),rownames(set2)),ntree=ntree))
    }
    k<-k[k[,1]>0,]
    rownames(k)<-c("p36",paste("top",1:(nrow(k)-1),sep=""))
    colnames(k)<-c("N.of.proteins","N","Y")
    
    return(k)
}



# LVEF correlation
LVEFcorr<-function(Expr,Design,Annotation){
    cors<-matrix(0,nrow(Expr),4)
    for(i in 1:nrow(Expr)){
        cors[i,1]<-rownames(Expr)[i]
        w<-which(Design[,54]!="---")
        cors[i,2]<-suppressWarnings(cor(as.numeric(as.character(Expr[i,w])),as.numeric(as.character(Design[w,54])),method="spearman"))
        cors[i,3]<-suppressWarnings(cor.test(as.numeric(as.character(Expr[i,w])),as.numeric(as.character(Design[w,54])),method="spearman")$p.value)
        cors[i,4]<-1
    }
    cors[,4]<-p.adjust(as.numeric(as.character(cors[,3])),"BH")
    colnames(cors)<-c("ID","Spearman_rho","P.Value","adj.P.Val")
    mm<-match(as.character(cors[,1]),rownames(Annotation))
    Annotation<-Annotation[mm,]
    cors<-cbind(Annotation,cors[,-1])
    cors<-cors[sort.list(cors$adj.P.Val),]
    
 return(cors)
}


# tSNE plot
TSNEplot<-function(Expr,Design,Annotation,diseaseColumn,cohort,top=1000){
    
    Design<-as.matrix(Design)
    if(cohort=="CDCS"){
        Design[Design[,diseaseColumn]=="incident_HF",diseaseColumn]<-"HF"
    } else {
        Design[Design[,diseaseColumn]=="Y",diseaseColumn]<-"HF"
        Design[Design[,diseaseColumn]=="N",diseaseColumn]<-"Control"
    }
    Design<-data.frame(Design)
    if(cohort=="CDCS"){
        w<-which(Annotation$Flag=="PASS")
    } else {
        w<-which(Annotation$FlagA=="PASS")
    }
    Expr1<-Expr[w,]
    vv<-apply(Expr1,1,var)
    sl<-sort.list(vv,decreasing=T)
    Expr1<-t(Expr1[sl,])[,1:min(top,nrow(Expr1))]
    tsne<-Rtsne(Expr1,perplexity=floor(nrow(Expr1)/5),dims=2)
    
    mydata<-data.frame(Dim1=tsne$Y[,1],Dim2=tsne$Y[,2],Condition=Design[,diseaseColumn])
    p1<-ggplot(mydata,aes(x=Dim1,y=Dim2,color=Condition)) + geom_point() + ggtitle(paste("tSNE of ",cohort,sep=""))
 print(p1)
 
}


# PCA plot
PCAplot<-function(Expr,Design,Annotation,diseaseColumn,cohort,top=1000){
    
    Design<-as.matrix(Design)
    if(cohort=="CDCS"){
        Design[Design[,diseaseColumn]=="incident_HF",diseaseColumn]<-"HF"
    } else {
        Design[Design[,diseaseColumn]=="Y",diseaseColumn]<-"HF"
        Design[Design[,diseaseColumn]=="N",diseaseColumn]<-"Control"
    }
    Design<-data.frame(Design)
    if(cohort=="CDCS"){
        w<-which(Annotation$Flag=="PASS")
    } else {
        w<-which(Annotation$FlagA=="PASS")
    }
    Expr1<-Expr[w,]
    vv<-apply(Expr1,1,var)
    sl<-sort.list(vv,decreasing=T)
    Expr1<-t(Expr1[sl,])[,1:min(top,nrow(Expr1))]
    pca<-prcomp(Expr1)
    dd<-cbind(Expr1,Batch=as.character(Design$Batch))
    
    p1<-autoplot(pca,data=dd,colour="Batch")
 print(p1)
 
}





# Levene test for heteroscedasticity
LeveneTest<-function(Expr,Design,Annotation,cohort,diseaseColumn){
    
    if(cohort=="CDCS"){
        w<-which(Annotation$Flag=="PASS")
    } else {
        w<-which(Annotation$FlagA=="PASS")
    }
    Expr1<-Expr[w,]
    tst<-matrix(0,nrow(Expr1),3)
    for(i in 1:nrow(tst)){
        tst[i,1]<-rownames(Expr1)[i]
        tst[i,2]<-levene.test(as.numeric(as.character(Expr1[i,])),group=factor(Design[,diseaseColumn]),
            location="median",correction.method="zero.correction")$p
    }
    tst[,3]<-p.adjust(as.numeric(as.character(tst[,2])),"BH")
    tst<-data.frame(tst)
    colnames(tst)<-c("Protein","LeveneP","adj.P.Val")
    tst<-tst[sort.list(as.numeric(as.character(tst$LeveneP))),]
    
    return(tst)
 
}


# dimensionality reduction for IMMACULATE (user-defined proteins)
redDim_IMMACULATE<-function(Expr,Design,Annotation,proteins,legend,diseaseColumn,plotit=TRUE){
    
    Design<-as.matrix(Design)
    Design[Design[,diseaseColumn]=="Y",diseaseColumn]<-"HF"
    Design[Design[,diseaseColumn]=="N",diseaseColumn]<-"Control"
    Design<-data.frame(Design)
    
    w<-match(proteins,rownames(Expr))
    Expr1<-t(Expr[w,])
    tsne<-Rtsne(Expr1,perplexity=floor(nrow(Expr1)/3),dims=2)
    
    mydata<-data.frame(Dim1=tsne$Y[,1],Dim2=tsne$Y[,2],Condition=Design[,38])
    p1<-ggplot(mydata,aes(x=Dim1,y=Dim2,color=Condition)) + geom_point() +
        ggtitle(paste("tSNE of IMMACULATE for the ",legend,sep=""))
    mydata<-SingleCellExperiment(assays = list(logcounts=as.matrix(t(Expr1))),colData = Design)
    pp<-runPCA(mydata)@reducedDims$PCA
    mydata<-data.frame(PC1=pp[,1],PC2=pp[,2],Condition=Design[,38])
    p2<-ggplot(mydata,aes(x=PC1,y=PC2,color=Condition)) + geom_point() +
        xlab(paste("PC1 (",100*round(attributes(pp)$percentVar[1],3),"%)",sep="")) +
        ylab(paste("PC1 (",100*round(attributes(pp)$percentVar[2],3),"%)",sep="")) +
        ggtitle(paste("PCA of IMMACULATE for the ",legend,sep=""))
   
   if(plotit){
    print(multiplot(p1,p2))
   }
 return(mydata)
}


# calulate the cluster sum of squares
calc_SS <- function(df) sum(as.matrix(dist(df)^2)) / (2 * nrow(df))

# estimate the significance of separation between two clusters
clusterSignificance<-function(pcadata,proteins,randomSet=36,B=10000){
    
    meC<-apply(as.matrix(pcadata[pcadata[,3]=="Control",1:2]),2,mean)
    meHF<-apply(as.matrix(pcadata[pcadata[,3]=="HF",1:2]),2,mean)
    vC<-calc_SS(as.matrix(pcadata[pcadata[,3]=="Control",1:2])) / (length(which(pcadata[,3]=="Control"))-1)
    vHF<-calc_SS(as.matrix(pcadata[pcadata[,3]=="HF",1:2])) / (length(which(pcadata[,3]=="HF"))-1)
    test<-as.numeric(dist(rbind(meC, meHF)))/sqrt(vC + vHF)
    testB<-rep(0,B)
    
    for(i in 1:B){
        
        x<-i/100
        
        if(x%%1==0 | i==1 | i==B){
           print(paste("Now analyzing sample ",i,sep=""))
        }
        
        k <- redDim_IMMACULATE(Expr = data_IMMACULATE$Expr,
            Design = data_IMMACULATE$Design,
            Annotation = data_IMMACULATE$Annotation,
            proteins = sample(proteins,randomSet),
            legend = "",
            plotit=FALSE)
        meC<-apply(as.matrix(k[k[,3]=="Control",1:2]),2,mean)
        meHF<-apply(as.matrix(k[k[,3]=="HF",1:2]),2,mean)
        vC<-calc_SS(as.matrix(k[k[,3]=="Control",1:2])) / (length(which(pcadata[,3]=="Control"))-1)
        vHF<-calc_SS(as.matrix(k[k[,3]=="HF",1:2])) / (length(which(pcadata[,3]=="HF"))-1)
        testB[i]<-as.numeric(dist(rbind(meC, meHF)))/sqrt(vC + vHF)
    }
 return(list(test=test,testB=testB))
}


# volcano plot of proteins
VolcanoPlot<-function(de,cohort,interactive=TRUE){
    
    de<-de[which(de$Flag=="PASS"),]
    de$logFC<-as.numeric(as.character(de$logFC))
    ss<-rep("N",nrow(de))
    ss[de$adj.P.Val<=0.05]<-"Y"
    de$logP<- -log(as.numeric(as.character(de$P.Value)),10)
    de$Significance=factor(ss)
    de<-de[sort.list(de$Significance),]
    cc<-rep("#BBBBBB",nrow(de))
    cc[de$Significance=="Y"]<-"#6ACDDE"
    
    if(interactive){
        
        plot_ly(de,
            x=as.numeric(as.character(de$logFC)),
            y=as.numeric(as.character(de$logP)),
            color=de$Significance,
            colors=cc,
            type="scatter",
            text = paste(de$TargetFullName,
                ": logFC=",round(as.numeric(as.character(de$logFC)),3),
                " FDR=",scientific(as.numeric(as.character(de$adj.P.Val)),digits=3),sep="")) %>%
            layout(title=paste("Volcano plot of the ",cohort," cohort",sep=""),
                xaxis=list(title="logFC"),
                yaxis=list(title="-log10 PValue"))
        
    } else {
        
        p1<-ggplot(de,aes(x=logFC,y=logP,color=Significance)) + geom_point(size=1.5,shape=16) + ylab("-log10 PValue") + theme_bw()
        p1<- p1 + scale_color_manual(values=c("#BBBBBB","#6ACDDE","#6ACDDE")) + ggtitle(paste("Volcano plot of the ",cohort," cohort",sep=""))
        print(p1)
        
    }
}


# produce the data for plotting correlations
LVEFdata<-function(Expr,Design,Annotation,merged_table){

    cands<-merged_table[as.numeric(as.character(merged_table$DE_adj.P.Val))<=0.05 & as.numeric(as.character(merged_table$LVEF_adj.P.Val))<=0.05 & as.character(merged_table$Flag)=="PASS",]
    cands<-cands[-grep("Human-virus",rownames(cands)),]
    mm<-match(cands,as.character(rownames(Annotation)))
    Annotation<-Annotation[mm,]

    mm1<-unique(match(as.character(rownames(cands)),as.character(rownames(Expr))))
    w1<-which(as.character(Design[,54])!="---")
    data<-Expr[mm1,w1]
    desi<-Design[w1,]
    sl<-sort.list(as.numeric(as.character(desi[,54])))
    data<-data[,sl]
    desi<-desi[sl,]

    scaled<-data-rowMeans(data)
    sdata<-sdata_2<-scaled
    for(i in 1:nrow(sdata)){
        sdata[i,]<-glm(as.numeric(as.character(scaled[i,])) ~ ns(as.numeric(as.character(desi[,54])),df=1))$fitted.values
        sdata_2[i,]<-lowess(as.numeric(as.character(desi[,54])),as.numeric(as.character(scaled[i,])))$y
    }


    my.dist <- dist(t(sdata))
    my.tree <- hclust(my.dist, method = "ward.D2")
    my.clusters <- factor(as.character(desi[,9]))
    clust.col<-rep("#2196F3",nrow(desi))
    clust.col[my.clusters=="incident_HF"]<-"#E81E62"
    heat.vals <- sdata
    clust.row<-c("#6ACDDE","#71D4C2","#A2E4ED","#FA9DBE","#FEE9A4")
    prm <- gtools::permutations(n=5, r=5, v=clust.row)
    clust.row<-prm[41,]
    hc.rows<- hclust(dist(heat.vals))
    ct<- cutree(hc.rows, k=5)
    cr<-clust.row[ct]
    gg_smooth<-cbind(rownames(heat.vals),cr)
    colnames(gg_smooth)<-c("Gene","Clust_SMOOTH")
    oo<-hc.rows[[4]][hc.rows[[3]]]
    gg_smooth<-gg_smooth[match(oo,gg_smooth[,1]),]
    heat.vals<-heat.vals[match(gg_smooth[,1],rownames(heat.vals)),]
    gg<-GeneNames(rownames(heat.vals),k=2)
    gg[rownames(heat.vals)=="SL002785:NPPB"]<-"NT-proBNP"
    gg[rownames(heat.vals)=="SL000306:NPPB"]<-"BNP-32"
    gg[rownames(heat.vals)=="SL002505:NPPA"]<-"ANP"
    gg[rownames(heat.vals)=="SL007206:THBS2"]<-"TSP2"
    gg[rownames(heat.vals)=="SL007207:THBS4"]<-"TSP4"

    rownames(heat.vals)<-gg
    my_palette <- colorRampPalette(c(gg_color_hue(10)[7], "gray90", gg_color_hue(10)[1]))(n = 50)
    
    return(list(heat.vals=heat.vals,my_palette=my_palette,clust.col=clust.col,clust.row=clust.row,my.clusters=my.clusters,gg_smooth=gg_smooth,desi=desi,Annotation=Annotation,sdata=sdata,sdata_2=sdata_2))
}


# colors for the heatmap plot
gg_color_hue <- function(n) {
    hues = seq(15, 375, length = n + 1)
    hcl(h = hues, l = 65, c = 100)[1:n]
}


# LVEF analysis heatmap
LVEFheat<-function(data){
    
    superheat(data$heat.vals,scale=F,heat.pal=data$my_palette,left.label.size = 0.2,left.label.text.size = 1,bottom.label.col=data$clust.col,left.label.col=data$gg_smooth[,2],
        legend.width=1,legend.height=0.1,legend.text.size = 8)

}

# LVEF analysis smoothed expressions and clusters
LVEFsmooth<-function(data){

    design<-data$desi
    marker_data<-as.matrix(data$sdata_2)
    HCclusters<-unique(data$gg_smooth[,2])
    ylim<-range(marker_data)

    mydata<-matrix(as.numeric(as.character(design[,54])),ncol=1)
    i<-1
    w<-which(as.character(data$gg_smooth[,2])==HCclusters[i])
    dd<-matrix(marker_data[match(as.character(data$gg_smooth[w,1]),rownames(marker_data)),],ncol=ncol(marker_data))
    ci<-apply(dd,2,mean)
    mydata<-cbind(mydata,ci,rep(HCclusters[i],length(ci)))

    for(i in 2:length(HCclusters)){
        w<-which(as.character(data$gg_smooth[,2])==HCclusters[i])
        dd<-matrix(marker_data[match(as.character(data$gg_smooth[w,1]),rownames(marker_data)),],ncol=ncol(marker_data))
        ci<-apply(dd,2,mean)
        mydata<-rbind(mydata,cbind(matrix(as.numeric(as.character(design[,54])),ncol=1),ci,rep(HCclusters[i],length(ci))))
    }
    colnames(mydata)<-c("EF","Expression","Clusters")
    mydata<-data.frame(mydata)
    mydata[,1]<-as.numeric(as.character(mydata[,1]))
    mydata[,2]<-as.numeric(as.character(mydata[,2]))
    mydata[,3]<-factor(mydata[,3])
    
    cc<-as.character(mydata[,3])
    cc<-str_replace(cc,"#FEE9A4","Cluster 1")
    cc<-str_replace(cc,"#FA9DBE","Cluster 2")
    cc<-str_replace(cc,"#A2E4ED","Cluster 3")
    cc<-str_replace(cc,"#6ACDDE","Cluster 4")
    cc<-str_replace(cc,"#71D4C2","Cluster 5")
    mydata[,3]<-cc
    
    p1<-ggplot(mydata,aes(x=EF,y=Expression,group=Clusters,color=Clusters)) + geom_smooth(method="loess",span=0.7)
    p1<-p1+scale_color_manual(values=HCclusters) + xlab("EF at 4 months") + ylab("Normalized expression") + ylim(-0.2,0.4)
    print(p1)
}


# prepare the WGCNA data
prepareWGCNA<-function(exprs,counts,design,annot,sel,DEs,Ccut,adjustment=FALSE){
    
    if(!identical(rownames(exprs),rownames(counts))){
        stop("The genes of the expression & count tables differ")
    }
    if(!identical(rownames(exprs),rownames(annot))){
        stop("The genes of the expression & annotation tables differ")
    }
    if(!identical(rownames(counts),rownames(annot))){
        stop("The genes of the count & annotation tables differ")
    }
    if(!identical(colnames(exprs),rownames(design))){
        stop("The samples of the expression & design tables differ")
    }
    if(!identical(colnames(counts),rownames(design))){
        stop("The samples of the count & design tables differ")
    }
    wgcna.params <- list()
    wgcna.params$maxBlockSize = 5000
    wgcna.params$networkType = "signed"
    wgcna.params$TOMType = "signed"
    wgcna.params$detectCutHeight = 0.995 # dendrogram cut height for module detection
    wgcna.params$deepSplit = 2 # (1,4) sensitivity for module splitting (4 = most sensiti ve)
    wgcna.params$minModuleSize = 500
    wgcna.params$pamStage = TRUE # 2nd PAM-like stage of module detection
    wgcna.params$pamRespectsDendro = FALSE
    wgcna.params$minCoreKME = 0.5
    wgcna.params$wgcna.params$minCoreKMESize = wgcna.params$minModuleSize / 3
    wgcna.params$minKMEtoStay = 0.3
    wgcna.params$reassignThreshold = 1e-6
    wgcna.params$mergeCutHeight = 0.25

    wgcna.input <- exprs[,sel]
    counts1<-counts[,sel]
    sample.info.all <- design[sel,]
    
    if(adjustment){
        wgcna.input<-removeBatchEffect(wgcna.input,batch=sample.info.all$Condition)
        if(min(wgcna.input)<0){
            wgcna.input<-wgcna.input-min(wgcna.input)
        }
    }
    wgcna.input1<-t(wgcna.input)
    
    sample.attrib <- list()
    cl<-sample.info.all$Somalogic_Group_Summary
    sample.attrib$colors <- rainbow(length(unique(cl)))
    names(sample.attrib$colors) = paste("Group",sort(unique(cl)),sep="")
    sample.attrib$pch <- 20:(20+length(unique(cl))-1)
    names(sample.attrib$pch) <- paste("Group",sort(unique(cl)),sep="")
    
    if(!identical(colnames(wgcna.input1),rownames(counts1))){
        stop("The genes of the expression & count tables differ (after processing)")
    }
    if(!identical(rownames(wgcna.input1),colnames(counts1))){
        stop("The samples of the expression & count tables differ (after processing)")
    }
    if(!identical(rownames(counts1),rownames(annot))){
        stop("The genes of the count & annotation tables differ (after processing)")
    }
    if(!identical(rownames(wgcna.input1),rownames(sample.info.all))){
        stop("The samples of the expression & design tables differ (after processing)")
    }
    if(!identical(colnames(counts1),rownames(sample.info.all))){
        stop("The samples of the count & design tables differ (after processing)")
    }

  return(list(Data = wgcna.input1, Design = sample.info.all, Annotation = annot, Attributes = sample.attrib, Parameters = wgcna.params, DEs = DEs, Counts = t(counts1)))
}


# split the WGCNA data by a factor
splitWGCNA<-function(data,split_factor,split_column){
    w1<-which(data$Design[,split_column]==split_factor[1])
    w2<-which(data$Design[,split_column]==split_factor[2])
    w3<-which(data$Design[,split_column]==split_factor[3])
    data1<-data$Data[w1,]
    data2<-data$Data[w2,]
    data3<-data$Data[w3,]
    des1<-data$Design[w1,]
    des2<-data$Design[w2,]
    des3<-data$Design[w3,]
    counts1<-data$Counts[w1,]
    counts2<-data$Counts[w2,]
    counts3<-data$Counts[w3,]
    All1<-list(Data=data1,Design=des1,Annotation = data$Annotation, Attributes = data$Attributes, Parameters = data$Parameters, DEs = data$DEs, Counts = counts1)
    All2<-list(Data=data2,Design=des2,Annotation = data$Annotation, Attributes = data$Attributes, Parameters = data$Parameters, DEs = data$DEs, Counts = counts2)
    All3<-list(Data=data3,Design=des3,Annotation = data$Annotation, Attributes = data$Attributes, Parameters = data$Parameters, DEs = data$DEs, Counts = counts3)
 return(list(Dataset1 = All1, Dataset2 = All2, Dataset3 = All3))
}


# soft thresholding for WGCNA
SoftThresh<-function(data){
    powers = c(c(1:10), seq(from=12, to=20, by=2))
    sft <- pickSoftThreshold(data$Data, powerVector=powers, verbose=5)
    sizeGrWindow(9,5)
    par(mfrow=c(1,2))
    cex1 = 0.9
    plot(sft$fitIndices[,1],
        -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
        xlab='Soft Threshold (power)',
        ylab='Scale Free Topology Model Fit, signed R^2',
        type='n', main=paste('Scale Independence'))
    text(sft$fitIndices[,1],
        -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
        labels=powers, cex=cex1, col='red')
    abline(h=0.90, col='red')
    
    plot(sft$fitIndices[,1], sft$fitIndices[,5],
        xlab='Soft Threshold (power)',
        ylab='Mean Connectivity', type='n',
        main=paste('Mean connectivity'))
    text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1, col='red')
 return(sft)
}


# soft connectivity for WGCNA
SoftConnectivity=function(datE, power,batchsize=1500,MinimumNoSamples=10) {
    no.genes=dim(datE)[[2]]
    no.samples=dim(datE)[[1]]
    sum1=function(x) sum(x,na.rm=T)
    k=rep(NA,no.genes)
    no.batches=as.integer(no.genes/ batchsize)
    if (no.batches>0) {
        for (i in 1:no.batches) {
            print(paste("batch number = ", i))
            index1=c(1:batchsize)+(i-1)* batchsize
            ad1=abs(cor(datE[,index1], datE,use="p"))^power
            ad1[is.na(ad1)]=0
            k[index1]=apply(ad1,1,sum1)
            # If fewer than MinimumNoSamples contain gene expression information for a given
            # gene, then we set its connectivity to 0.
            NoSamplesAvailable=apply(!is.na(datE[,index1]),2,sum)
            k[index1][NoSamplesAvailable< MinimumNoSamples]=NA
        } # end of for (i in 1:no.batches
    } # end of if (no.batches>0)...
    if (no.genes-no.batches*batchsize>0 ) {
        restindex=c((no.batches*batchsize+1):no.genes)
        ad1=abs(cor(datE[,restindex], datE,use="p"))^power
        ad1[is.na(ad1)]=0
        k[restindex]=apply(ad1,1,sum1)
        NoSamplesAvailable=apply(!is.na(datE[,restindex]),2,sum)
        k[restindex][NoSamplesAvailable< MinimumNoSamples]=NA
    }
    
    k
}


# runs the first step of the WGCNA anaysis (conectivity & thresholding)
WGCNAanalysis<-function(Expr,Design,Annotation,DEs,ppHF,ppC,de_cut=0.05,est.power=FALSE){
    
    DEs<-DEs[as.numeric(as.character(DEs$adj.P.Val))<=de_cut,]

    keep<-which(Annotation$Flag=="PASS")
    data<-Expr[keep,]
    annot<-Annotation[keep,]
    wgcnaData<-prepareWGCNA(exprs=data,counts=data,adjustment=FALSE,design=Design,annot=annot,sel=1:nrow(Design),DEs=DEs,Ccut=20)
    wgcnaData<-splitWGCNA(data=wgcnaData,split_factor=c("incident_HF","Control"),split_column=9)
    wgcnaData_HF<-wgcnaData$Dataset1
    wgcnaData_Control<-wgcnaData$Dataset2

    sft_HF<-SoftThresh(data=wgcnaData_HF)
    sft_Control<-SoftThresh(data=wgcnaData_Control)
    
    if(est.power){
        ppHF<-sft_HF$powerEstimate
        ppC<-sft_Control$powerEstimate
    }
    sc_HF<-SoftConnectivity(wgcnaData_HF$Data, power=ppHF,MinimumNoSamples=10)
    sc_Control<-SoftConnectivity(wgcnaData_Control$Data, power=ppC,MinimumNoSamples=10)
    K1<-sc_HF/max(sc_HF)
    K2<-sc_Control/max(sc_Control)
    DiffK<-K1-K2
    
 return(list(wgcnaData=wgcnaData,wgcnaData_HF=wgcnaData_HF,wgcnaData_Control=wgcnaData_Control,sft_HF=sft_HF,sft_Control=sft_Control,ppHF=ppHF,ppC=ppC,sc_HF=sc_HF,sc_Control=sc_Control,K1=K1,K2=K2,DiffK=DiffK))
}



# find the TOM of WGCNA
findTOM<-function(data,power,cor_type="cor"){
    adjacency <- adjacency(data$Data, power=power, type=data$Parameters$networkType,corFnc=cor_type)
    TOM <- TOMsimilarity(adjacency,TOMType=data$Parameters$networkType)
    colnames(TOM) <- colnames(adjacency)
    rownames(TOM) <- rownames(adjacency)
    dissTOM <- 1-TOM
    dissTOM2<-as.dist(dissTOM)
    peakTree <- hclust(dissTOM2, method="average")
    plot(peakTree, xlab="", sub="", main = "Peak clustering on TOM-based dissimilarity", labels = FALSE, hang = 0.04);
 return(list(TOM = TOM, dissTOM = dissTOM, Tree = peakTree))

}


# initialize the WGCNA modules
FirstModules<-function(data,TOMdata){
    dynamicMods <- cutreeDynamic(dendro=TOMdata$Tree, method="hybrid", distM=TOMdata$dissTOM,
        cutHeight=data$Parameters$detectCutHeight,
        deepSplit=data$Parameters$deepSplit,
        pamRespectsDendro=FALSE,
        minClusterSize=data$Parameters$minModuleSize, verbose = 2)
    #table(dynamicMods)
    
    dynamicColors <- labels2colors(dynamicMods)
    #table(dynamicColors)
    plotDendroAndColors(TOMdata$Tree, dynamicColors, "Dynamic Tree Cut", dendroLabels=FALSE, hang=0.03,
        addGuide=TRUE, guideHang=0.05, main="Peak dendrogram and module colors")
    
    MEList <- moduleEigengenes(data$Data, colors=dynamicColors,
        softPower=data$Parameters$softPower, nPC=1)
    MEs = MEList$eigengenes
    rownames(MEs) <- rownames(data$Data)
    MEDiss <- 1-cor(MEs)
    METree <- hclust(as.dist(MEDiss), method="ward.D2")
    #plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
 return(list(ME = MEs, dissME = MEDiss, DynamicColors = dynamicColors))

}


# merges the initialized WGCNA modules
MergedModules<-function(data,ModuleData,TOMdata){
    merge = mergeCloseModules(data$Data, ModuleData$DynamicColors,
        cutHeight=data$Parameters$mergeCutHeight, verbose=3)
    mergedColors = merge$colors
    mergedMEs = merge$newMEs
    plotDendroAndColors(TOMdata$Tree, cbind(ModuleData$DynamicColors, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"),
        dendroLabels=FALSE, hang=0.03, addGuide=TRUE, guideHang=0.05)
    #table(mergedColors)
    
    moduleColors = mergedColors
    names(moduleColors) = colnames(data$Data)
    colorOrder = c("grey", standardColors(50))
    moduleLabels = match(moduleColors, colorOrder)-1
    MEs = mergedMEs
    rownames(MEs) <- rownames(data$Data)
    colnames(MEs) = substring(names(MEs), 3)
 return(list(ME = MEs, DynamicColors = mergedColors))

}


# find the proteins of each module
ModuleGenes<-function(data,ModuleData,TFs,Epig,topGenes=100000,Pcut=1){
    modulesA1<-ModuleData$DynamicColors
    ME_1A<-ModuleData$ME
    colorsA1 <- names(table(modulesA1))
    datExprA1g<-t(data$Data)
    annot<-data$Annotation
    DEs<-data$DEs
    
    geneModuleMembership1 = signedKME(t(datExprA1g), ME_1A)
    colnames(geneModuleMembership1)=paste("PC",colnames(ME_1A),".cor",sep="")
    MMPvalue1=corPvalueStudent(as.matrix(geneModuleMembership1),dim(datExprA1g)[[2]])
    colnames(MMPvalue1)=paste("PC",colnames(ME_1A),".pval",sep="")
    Gene       = rownames(datExprA1g)
    kMEtable1  = cbind(Gene,Gene,modulesA1)
    for (i in 1:length(colorsA1)){
        kMEtable1 = cbind(kMEtable1, geneModuleMembership1[,i], MMPvalue1[,i])
    }
    colnames(kMEtable1)=c("PSID","Gene","Module",paste(rep(colorsA1,each=2),rep(c("_cor","_Pvalue"),length(colorsA1)),sep=""))
    #write.table(kMEtable1,"kMEtable.txt",sep="\t",row.names=FALSE,col.names=TRUE)

    topGenesKME = NULL
    mods<-names(table(modulesA1))
    column<-matrix(0,length(mods),2)
    for(i in 1:length(mods)){
        cc<-which(colnames(kMEtable1)==paste(mods[i],"_cor",sep=""))
        column[i,]<-c(cc,cc+1)
    }
    #tops<-10000  # how many genes to show
    #pcut<-1      # how many of the top genes have significant correlation p-value
    cols<-c()
    for (i in 1:nrow(column)){
        ww<-which(kMEtable1[,3]==mods[i])
        d1<-as.numeric(kMEtable1[ww,column[i,1]])
        d2<-as.numeric(kMEtable1[ww,column[i,2]])
        genes<-kMEtable1[ww,2]
        cor.ranks<-rank(abs(d1))
        kMErank1    = cbind(abs(cor.ranks-max(cor.ranks))+1,d1,d2)
        tops2<-min(topGenes,length(d1))
        d3<-cbind(genes[kMErank1[,1]<=tops2],kMErank1[kMErank1[,1]<=tops2,2:3])
        d3<-d3[sort.list(as.numeric(d3[,3])),]
        d3[which(as.numeric(d3[,3])>Pcut),]<-""
        if(nrow(d3)!=topGenes){
            d3<-rbind(d3,matrix("",(topGenes-nrow(d3)),3))
        }
        topGenesKME<-cbind(topGenesKME,d3)
        cols1<-paste(unlist(strsplit(colnames(kMEtable1)[column[i,1]],".",fixed=TRUE))[1],".Gene",sep="")
        cols<-c(cols,cols1,colnames(kMEtable1)[column[i,1:2]])
    }
    colnames(topGenesKME)<-cols

    cc<-seq(1,ncol(topGenesKME),3)
    annot_top_modules<-as.list(rep(0,length(cc)))
    for(i in 1:length(cc)){
        ii<-intersect(topGenesKME[,cc[i]],rownames(annot))
        aa<-annot[ii,]
        mm1<-match(rownames(aa),TFs,nomatch=0)
        mm1[mm1!=0]<-"TF"
        mm2<-match(rownames(aa),Epig,nomatch=0)
        mm2[mm2!=0]<-"Epig"
        annot_top_modules[[i]]<-cbind(aa,isTF = mm1,is.Epig=mm2,Module = rep(colnames(topGenesKME)[cc[i]],length(ii)),
            Cor = as.numeric(as.character(topGenesKME[1:length(ii),(cc[i]+1)])),CorSig = as.numeric(as.character(topGenesKME[1:length(ii),(cc[i]+2)])))
        annot_top_modules[[i]]<-as.matrix(annot_top_modules[[i]])
        #write.table(annot_top_modules[[i]],paste("Annotation_module_",mods[i],".txt",sep=""),sep="\t",row.names=FALSE,col.names=TRUE)
    }
    
    for(i in 1:length(mods)){
        DEmodule_genes<-annot_top_modules[[i]]
        mm<-match(as.character(rownames(DEmodule_genes)),as.character(data$DEs[,1]))
        des<-as.matrix(data$DEs[mm,])
        ii<-is.na(des[,1])
        des[ii,]<-"---"
        annot_top_modules[[i]]<-cbind(DEmodule_genes,DEcomp=des[,c(2,5)])
        colnames(annot_top_modules[[i]])<-c(colnames(DEmodule_genes),colnames(data$DEs)[c(2,5)])
    }
  return(list(GeneModules = topGenesKME, GeneModuleAnnotation = annot_top_modules,mods=mods))
}

# runs the second step of the WGCNA anaysis (clustering and modules)
WGCNAmodules<-function(wgcnaData,TFs,EFs){

    TOM_HF<-findTOM(data=wgcnaData$wgcnaData_HF,power=wgcnaData$ppHF)
    wgcnaData$wgcnaData_HF$Parameters$softPower<-wgcnaData$ppHF
    TOM_Control<-findTOM(data=wgcnaData$wgcnaData_Control,power=wgcnaData$ppC)
    wgcnaData$wgcnaData_Control$Parameters$softPower<-wgcnaData$ppC

    wgcnaData$wgcnaData_HF$Parameters$minModuleSize<-50
    wgcnaData$wgcnaData_HF$Parameters$detectCutHeight<-0.95
    ME_HF<-FirstModules(data=wgcnaData$wgcnaData_HF,TOMdata=TOM_HF)
    wgcnaData$wgcnaData_Control$Parameters$minModuleSize<-50
    wgcnaData$wgcnaData_Control$Parameters$detectCutHeight<-0.95
    ME_Control<-FirstModules(data=wgcnaData$wgcnaData_Control,TOMdata=TOM_Control)

    wgcnaData$wgcnaData_HF$Parameters$mergeCutHeight<-0.2
    cl<-ME_HF$DynamicColors
    cl[cl=="grey"]<-"#FF5733"
    cl[cl=="blue"]<-"#581845"
    cl[cl=="turquoise"]<-"#C70039"
    ME_HF$DynamicColors<-cl
    meME_HF<-MergedModules(data=wgcnaData$wgcnaData_HF,ModuleData=ME_HF,TOMdata=TOM_HF)
    wgcnaData$wgcnaData_Control$Parameters$mergeCutHeight<-0.2
    cl<-ME_Control$DynamicColors
    cl[cl=="grey"]<-"#A2E4ED"
    cl[cl=="turquoise"]<-"#A2EDD1"
    ME_Control$DynamicColors<-cl
    meME_Control<-MergedModules(data=wgcnaData$wgcnaData_Control,ModuleData=ME_Control,TOMdata=TOM_Control)

    names(wgcnaData$K1)<-colnames(wgcnaData$wgcnaData_HF$Data)
    names(wgcnaData$K2)<-colnames(wgcnaData$wgcnaData_Control$Data)

    ModGenes_HF<-ModuleGenes(data=wgcnaData$wgcnaData_HF,ModuleData=meME_HF,TFs=TFs,Epig=EFs)
    module_data_HF<-module_data_Control<-matrix(0,1,16)
    for(i in 1:length(ModGenes_HF[[2]])){
        d1<-ModGenes_HF[[2]][[i]]
        mm<-match(rownames(ModGenes_HF[[2]][[i]]),names(wgcnaData$K1))
        d2<-wgcnaData$K1[mm]
        module_data_HF<-rbind(module_data_HF,cbind(d1[,1:12],Connectivity=d2,d1[,13:14],ModuleName=rep(paste("ModAnnot_HF",i,sep=""),nrow(d1))))
    }
    module_data_HF<-data.frame(module_data_HF[-1,])
    
    ModGenes_Control<-ModuleGenes(data=wgcnaData$wgcnaData_Control,ModuleData=meME_Control,TFs=TFs,Epig=EFs)
    for(i in 1:length(ModGenes_Control[[2]])){
        d1<-ModGenes_Control[[2]][[i]]
        mm<-match(rownames(ModGenes_Control[[2]][[i]]),names(wgcnaData$K2))
        d2<-wgcnaData$K2[mm]
        module_data_Control<-rbind(module_data_Control,cbind(d1[,1:12],Connectivity=d2,d1[,13:14],ModuleName=rep(paste("ModAnnot_Control",i,sep=""),nrow(d1))))
    }
     module_data_Control<-data.frame(module_data_Control[-1,])
     
 return(list(module_data_HF=module_data_HF,module_data_Control=module_data_Control))
}


# limma DE analysis for the permuted data of DiNA
DEstep<-function(data,desi){
    Group<-factor(desi)
    Group<-relevel(Group,ref="Control")
    design <- model.matrix(~ 0 + Group)
    colnames(design)<-c("Control","HF")
    fit <- lmFit(data,design)
    contrast.matrix <- makeContrasts(HF-Control, levels=design)
    fit2 <- contrasts.fit(fit, contrast.matrix)
    fit2 <- eBayes(fit2)
    HF_vs_Control<-topTable(fit2,coef=1,adjust="BH",n=nrow(data))
    DEs<-cbind(HF_vs_Control,Comparison="HF-Control")
    return(DEs)
}


# permute the wgcna data
permuteWGCNA<-function(data1,data2){
    perm<-rbind(data1$Data,data2$Data)
    perm<-perm[sample(1:nrow(perm),nrow(perm)),]
    permData1<-perm[1:nrow(data1$Data),]
    permData2<-perm[(nrow(data1$Data)+1):nrow(perm),]
    permcounts1<-perm[1:nrow(data1$Counts),]
    permcounts2<-perm[(nrow(data1$Counts)+1):nrow(perm),]
    des1<-data1$Design
    des1[,1]<-rownames(permData1)
    rownames(des1)<-des1[,1]
    des2<-data2$Design
    des2[,1]<-rownames(permData2)
    rownames(des2)<-des2[,1]
    All1<-list(Data=permData1,Design=des1,Annotation = data1$Annotation, Attributes = data1$Attributes, Parameters = data1$Parameters, DEs = data1$DEs, Counts = permcounts1)
    All2<-list(Data=permData2,Design=des2,Annotation = data2$Annotation, Attributes = data2$Attributes, Parameters = data2$Parameters, DEs = data2$DEs, Counts = permcounts2)
    return(list(Dataset1 = All1, Dataset2 = All2))
}


# permulation and t-test / DiffK stats for wgcna
wgcnaStatsFromPermutation<-function(wgcnaData,rsq.cut=0.9,do.ttest=FALSE,B=100000){
    
    test_perm<-DiffK_perm<-matrix(0,ncol(wgcnaData$wgcnaData_HF$Data),B)
    for(k in 1:B){
        
        x<-k/100
        
        if(x%%1==0 | k==1 | k==B){
           print(paste("Now running permutation ",k,sep=""))
        }
        
        perm<-permuteWGCNA(data1=wgcnaData$wgcnaData_HF,data2=wgcnaData$wgcnaData_Control)
        perm_HF<-perm$Dataset1
        perm_Control<-perm$Dataset2
        f = file()
        sink(file=f)
        sft_HF <- pickSoftThreshold(perm_HF$Data, powerVector=wgcnaData$ppHF:12, verbose=0,indent=0,RsquaredCut=rsq.cut)
        sft_Control <- pickSoftThreshold(perm_Control$Data, powerVector=wgcnaData$ppC:12, verbose=0,indent=0,RsquaredCut=rsq.cut)
        sink()
        close(f)
        if(is.na(sft_HF$powerEstimate) | is.na(sft_Control$powerEstimate)){
            pp<-12
        } else {
            pp<-max(sft_HF$powerEstimate,sft_Control$powerEstimate)
        }
        sc_perm_HF<-SoftConnectivity(perm_HF$Data, power=pp)
        sc_perm_Control<-SoftConnectivity(perm_Control$Data, power=pp)
        KHF_perm<-sc_perm_HF/max(sc_perm_HF)
        KC_perm<-sc_perm_Control/max(sc_perm_Control)
        DiffK_perm[,k]<-KHF_perm-KC_perm
        if(do.ttest){
            ff1<-factor(rep(c("HF","Control"),c(nrow(perm_HF$Data),nrow(perm_Control$Data))))
            dd<-t(rbind(as.matrix(perm_HF$Data),as.matrix(perm_Control$Data)))
            tt<-DEstep(data=dd,desi=ff1)
            tt<-tt[match(colnames(perm_HF$Data),rownames(tt)),]
            test_perm[,k]<-as.numeric(as.character(tt$t))
        }
    }
 return(list(DiffK=DiffK_perm,t=test_perm))

}


# summarise the DiNA results
summariseDiNA<-function(wgcnaData,wgcnaModules,DiffK,DEs,de.fdr.cut,diffk.cut,diffk.fdr.cut,permStats){
    
    mm<-match(colnames(wgcnaData$wgcnaData_HF$Data),DiffK[,1])
    DiffK<-DiffK[mm,]
    
    int_DiffK <- matrix(0, nrow(permStats), 3)
    for(i in 1:nrow(permStats)){
        
        if(as.numeric(as.character(DiffK[i, 2]))>0){
            pv<-length(which(as.numeric(as.character(permStats[i, ]))>as.numeric(as.character(DiffK[i, 2]))))/ncol(permStats)
        } else {
            pv<-length(which(as.numeric(as.character(permStats[i, ]))<as.numeric(as.character(DiffK[i, 2]))))/ncol(permStats)
        }
        
        int_DiffK[i, ] <- c(colnames(wgcnaData$wgcnaData_HF$Data)[i],
                            as.numeric(as.character(DiffK[i, 2])), pv)
    }

    mm <- match(as.character(int_DiffK[,1]), as.character(rownames(DEs)), nomatch = 0)
    de <- DEs[mm, ]
    wgcnaModules$module_data_HF <- wgcnaModules$module_data_HF[match(as.character(int_DiffK[,1]),
                                            as.character(rownames(wgcnaModules$module_data_HF))),]
      
      HFmodule_results <- cbind(wgcnaModules$module_data_HF[,c(1:9,11:12,16)],
                              logFC = as.numeric(as.character(de$logFC)),
                              Ttest = as.numeric(as.character(de$logFC)),
                              DE_PV = as.numeric(as.character(de$P.Value)),
                              DE_FDR = as.numeric(as.character(de$adj.P.Val)),
                              DiffK = int_DiffK[, 2],
                              DiffK_PV = int_DiffK[, 3],
                              DiffK_FDR = p.adjust(as.numeric(as.character(int_DiffK[, 3])),"BH"),
                              Comparison = as.character(de$Comparison))
    
    signf<-rep("N",nrow(HFmodule_results))
    signf[as.numeric(as.character(HFmodule_results$DE_FDR))<=de.fdr.cut &
          as.numeric(as.character(HFmodule_results$DiffK_FDR))<=diffk.fdr.cut &
          abs(as.numeric(as.character(HFmodule_results$DiffK)))>=diffk.cut]<-"Y"
    HFmodule_results <- cbind(HFmodule_results, DiNA_significance = signf)
    

 return(HFmodule_results)
 
}


# plot the DiNA results
plotDiNA<-function(DiNAdata,interactive=TRUE){
    
    cc<-rep("#BBBBBB",nrow(DiNAdata))
    cc[DiNAdata$DiNA_significance=="Y"]<-"#6ACDDE"
    
    if(interactive){
         
         plot_ly(DiNAdata,
             x=as.numeric(as.character(DiNAdata$Ttest)),
             y=as.numeric(as.character(DiNAdata$DiffK)),
             color=DiNAdata$DiNA_significance,
             colors=unique(cc),
             type="scatter",
             text = paste(DiNAdata$TargetFullName,
                 ": ",DiNAdata$ModuleName," (DE_FDR = ",scientific(DiNAdata$DE_FDR,digits=2),"   &   DiffK_FDR = ",scientific(DiNAdata$DiffK_FDR,digits=2),")",sep="")) %>%
             layout(title="DiNA results in CDCS",
                 xaxis=list(title="Tstat (HF - Control)"),
                 yaxis=list(title="DiffK (HF - Control)"))
         
     } else {
         
         DiNAdata$DiffK<-as.numeric(as.character(DiNAdata$DiffK))
         DiNAdata$ttest<-as.numeric(as.character(DiNAdata$Ttest))
         p1<-ggplot(DiNAdata,aes(x=ttest,y=DiffK,color=DiNA_significance)) + geom_point(size=1.5,shape=16) + ylab("DiffK (HF - Control)") + xlab("Tstat (HF - Control)") + theme_bw()
         p1<- p1 + scale_color_manual(values=c("#BBBBBB","#6ACDDE","#6ACDDE")) + ggtitle("DiNA results in CDCS")
         print(p1)
         
     }
    
}



# analysis on non-myocytes
scrna_nonmyocytes<-function(scExpr,scDesign,scDE,pDE,lvefStats){

    scDE[,2]<- -as.numeric(as.character(scDE[,2]))
    scDE<-scDE[sort.list(as.numeric(as.character(scDE[,2]))),]
    scDE<-scDE[abs(as.numeric(as.character(scDE$logFC)))>1,]
    scDE<-scDE[as.numeric(as.character(scDE$adj.P.Val))<=0.1,]
    
    deKeep<-scDE
    
    pDE<-as.matrix(pDE[-grep("Human-virus",as.character(pDE[,1])),])
    pDE_new<-matrix(0,1,ncol(pDE))
    for(i in 1:nrow(pDE)){
        tt<-unlist(strsplit(GeneNames(as.character(pDE[i,1]),k=2),"_"))
        if(length(tt)>1){
            dd<-t(matrix(rep(pDE[i,],length(tt)),ncol=length(tt)))
            dd[,1]<-tt
            pDE_new<-rbind(pDE_new,dd)
        } else {
            pDE_new<-rbind(pDE_new,pDE[i,])
        }
    }
    pDE<-data.frame(pDE_new[-1,])

    mm<-match(tolower(GeneNames(as.character(scDE[,1]),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0)
    pDE<-pDE[mm,]
    scDE<-scDE[mm>0,]
    scDE<-scDE[scDE$CellType=="Fibroblast",]
    mm<-match(tolower(GeneNames(as.character(scDE[,1]),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0)
    pDE<-pDE[mm,]
    scDE<-scDE[mm>0,]

    fibs<-as.character(pDE[,1])
    col.idx<-rep("#BBBBBB",length(fibs))
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2])))]<-"#FEE9A4"
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))<=0.05]<-"#71D4C2"
    col.idx[sign(as.numeric(as.character(pDE[,6])))!=sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))>0.05]<-"white"
    col.idx2<-rep("gray",nrow(scDE))
    col.idx2[as.numeric(as.character(scDE$adj.P.Val))<=1e-3]<-"cyan"
    fibs<-cbind(fibs,col.idx,col.idx2)
    out<-which(fibs[,2]=="white") #| fibs[,2]=="#BBBBBB")
    fibs<-fibs[-out,]
    scDE<-scDE[-out,]
    pDE<-pDE[-out,]

    mm<-match(rownames(scDesign),colnames(scExpr))
    scExpr<-scExpr[,mm]
    ro<-unique(match(tolower(GeneNames(fibs,k=2)),tolower(GeneNames(rownames(scExpr),k=2)),nomatch=0))
    co<-which(scDesign$Final_groups=="Fibroblast")
    data1<-scExpr[unique(ro),co]
    desi1<-scDesign[co,]
    sl<-sort.list(desi1$Condition,decreasing=T)
    data1<-log(data1[,sl]+1,2)
    desi1<-desi1[sl,]
    scDE<-scDE[match(tolower(GeneNames(rownames(data1),k=2)),tolower(GeneNames(as.character(scDE[,1]),k=2)),nomatch=0),]
    pDE<-pDE[match(tolower(GeneNames(rownames(data1),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0),]
    fibs<-fibs[match(tolower(GeneNames(rownames(data1),k=2)),tolower(GeneNames(fibs[,1],k=2)),nomatch=0),]

    sort.it=TRUE
    sham<-data1[,desi1$Condition=="Sham"]
    mi<-data1[,desi1$Condition=="MI"]
    my_palette <- colorRampPalette(c(gg_color_hue(10)[7], "gray90", gg_color_hue(10)[1]))(n = 50)
    if(sort.it){
        aa1<-apply(sham,2,median)
        aa2<-apply(mi,2,median)
        sham<-sham[,sort.list(aa1,decreasing=TRUE)]
        mi<-mi[,sort.list(aa2)]
    }
    data1<-cbind(sham,mi)
    desi1<-desi1[match(colnames(data1),rownames(desi1)),]
    heat.vals <- data1-rowMeans(data1)
    rownames(heat.vals)<-GeneNames(rownames(heat.vals),k=2)
    my.dist <- dist(t(heat.vals))
    my.tree <- hclust(my.dist, method = "average")
    my.clusters <- factor(as.character(desi1[,4]))
    clust.col<-rep("#2196F3",nrow(desi1))
    clust.col[my.clusters=="MI"]<-"#E81E62"
    gg.smooth<-cbind(Protein=as.character(scDE[,1]),logFC=as.numeric(as.character(scDE[,2])),rightCol=fibs[,3],leftCol=fibs[,2])

    superheat(heat.vals,scale=F,heat.pal=my_palette,left.label.size = 0.2,left.label.text.size = 2,bottom.label.col=clust.col,#pretty.order.col = TRUE,
        left.label.col=gg.smooth[,4],yr=as.numeric(gg.smooth[,2]),yr.plot.type="bar",yr.obs.col = gg.smooth[,3],yr.axis.name = "logFC",yr.num.ticks=5)

    gg.smooth[gg.smooth[,4]=="#71D4C2",4]<-"green"
    gg.smooth[gg.smooth[,4]=="#FEE9A4",4]<-"khaki"
    gg.smooth[gg.smooth[,4]=="#BBBBBB",4]<-"gray"
    gg.smooth<-cbind(gg.smooth,Flag=as.character(pDE$QC))
    
    i1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS"),1]
    i2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS"),1]
    i3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS"),1]

    j<-as.character(deKeep[,1])

    m1<-length(intersect(c(i1,i2),j))
    m2<-length(setdiff(j,c(i1,i2)))
    m3<-length(intersect(i3,j))
    m4<-length(setdiff(j,i3))

    mat<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat)<-c("Consistent","Inconsistent")
    rownames(mat)<-c("Common","Non-common")
    
    
    mm<-match(toupper(GeneNames(gg.smooth[,1],k=2)),as.character(lvefStats[,6]))
    lvefStats1<-lvefStats[mm,]
    mm<-match(toupper(GeneNames(deKeep[,1],k=2)),as.character(lvefStats[,6]))
    lvefStats2<-lvefStats[mm,]
    
    ii1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS" | as.numeric(as.character(lvefStats1[,10]))>0.05),1]

    jj<-as.character(deKeep[as.numeric(as.character(lvefStats2[,10]))<=0.05,1])

    m1<-length(intersect(c(ii1,ii2),jj))
    m2<-length(setdiff(jj,c(ii1,ii2)))
    m3<-length(intersect(ii3,jj))
    m4<-length(setdiff(jj,ii3))

    mat.lvef<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat.lvef)<-c("Consistent","Inconsistent")
    rownames(mat.lvef)<-c("Common","Non-common")

 return(list(gg.smooth,deKeep,mat,mat.lvef))
}


# analysis of mouse myocytes (ANOVA)
scrna_myocytes<-function(scExpr,scDesign,scDE,pDE,lvefStats){

    scDE1<-scDE[grep("B1",as.character(scDE$CellType)),]
    scDE2<-scDE[grep("B2",as.character(scDE$CellType)),]
    scDE1$logFC<- -as.numeric(as.character(scDE1$logFC))
    scDE2$logFC<- -as.numeric(as.character(scDE2$logFC))
    scDE1<-scDE1[abs(as.numeric(as.character(scDE1$logFC)))>1,]
    scDE2<-scDE2[abs(as.numeric(as.character(scDE2$logFC)))>1,]
    ii<-intersect(as.character(scDE1[,1]),as.character(scDE2[,1]))
    scDE1<-scDE1[match(ii,as.character(scDE1[,1])),]
    scDE2<-scDE2[match(ii,as.character(scDE2[,1])),]
    scDE1<-scDE1[as.numeric(as.character(scDE1$adj.P.Val))<=0.1,]
    scDE2<-scDE2[as.numeric(as.character(scDE2$adj.P.Val))<=0.1,]

    deKeep<-list(scDE1,scDE2)
    
    pDE<-as.matrix(pDE[-grep("Human-virus",as.character(pDE[,1])),])
    pDE_new<-matrix(0,1,ncol(pDE))
    for(i in 1:nrow(pDE)){
        tt<-unlist(strsplit(GeneNames(as.character(pDE[i,1]),k=2),"_"))
        if(length(tt)>1){
            dd<-t(matrix(rep(pDE[i,],length(tt)),ncol=length(tt)))
            dd[,1]<-tt
            pDE_new<-rbind(pDE_new,dd)
        } else {
            pDE_new<-rbind(pDE_new,pDE[i,])
        }
    }
    pDE<-data.frame(pDE_new[-1,])
    mm1<-match(tolower(GeneNames(as.character(scDE1[,1]),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0)
    mm2<-match(tolower(GeneNames(as.character(scDE2[,1]),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0)
    scDE1<-scDE1[mm1>0,]
    scDE2<-scDE2[mm2>0,]
    ii<-intersect(as.character(scDE1[,1]),as.character(scDE2[,1]))
    scDE1<-scDE1[match(ii,as.character(scDE1[,1])),]
    scDE2<-scDE2[match(ii,as.character(scDE2[,1])),]
    pDE<-pDE[match(tolower(GeneNames(ii,k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0),]

    scDE<-cbind(Protein=as.character(scDE1[,1]),logFC=apply(cbind(as.numeric(as.character(scDE1[,2])),as.numeric(as.character(scDE2[,2]))),1,median),
            Average=rep(1,nrow(scDE1)),FDR=apply(cbind(as.numeric(as.character(scDE1[,6])),as.numeric(as.character(scDE2[,6]))),1,median),
            Comp=rep("SHAM-TAC",nrow(scDE1)),CellType=rep("CM_mouse",nrow(scDE1)))
    sl<-sort.list(as.numeric(as.character(scDE[,2])))
    scDE<-scDE[sl,]
    scDE<-data.frame(scDE)
    pDE<-pDE[sl,]

    
    cm<-as.character(pDE[,1])
    col.idx<-rep("#BBBBBB",length(cm))
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2])))]<-"#FEE9A4"
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))<=0.05]<-"#71D4C2"
    col.idx[sign(as.numeric(as.character(pDE[,6])))!=sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))>0.05]<-"white"
    col.idx2<-rep("cyan",nrow(pDE))
    col.idx2[as.numeric(as.character(pDE$FDR))<=1e-3]<-"gray"
    cm<-cbind(cm,col.idx,col.idx2)
    out<-which(cm[,2]=="white")
    cm<-cm[-out,]
    scDE<-scDE[-out,]
    pDE<-pDE[-out,]

    
    desiB1<-cbind(scDesign$B1[,1:2],Day=rep("D1",nrow(scDesign$B1)),Batch=as.character(scDesign$B1[,3]))
    desiB2<-cbind(scDesign$B2[,1:2],Day=rep("D1",nrow(scDesign$B2)),Batch=as.character(scDesign$B2[,3]))
    ro1<-unique(match(GeneNames(cm[,1],k=2),toupper(GeneNames(rownames(scExpr$B1),k=2)),nomatch=0))
    ro2<-unique(match(GeneNames(cm[,1],k=2),toupper(GeneNames(rownames(scExpr$B2),k=2)),nomatch=0))
    co1.1<-which(desiB1$Condition=="SHAM")
    co1.2<-which(desiB1$Condition=="TAC")
    co2.1<-which(desiB2$Condition=="SHAM")
    co2.2<-which(desiB2$Condition=="TAC")
    
    dataB1sham<-log(scExpr$B1[ro1,co1.1]+1,2)
    dataB1tac<-log(scExpr$B1[ro1,co1.2]+1,2)
    dataB2sham<-log(scExpr$B2[ro2,co2.1]+1,2)
    dataB2tac<-log(scExpr$B2[ro2,co2.2]+1,2)
    
    
    dataTACB1<-cbind(dataB1sham,dataB1tac)
    dataTACB1<-dataTACB1-rowMeans(dataTACB1)
    dataTACB2<-cbind(dataB2sham,dataB2tac)
    dataTACB2<-dataTACB2-rowMeans(dataTACB2)
    
    
    dataSham<-cbind(dataTACB1[,1:length(co1.1)],dataTACB2[,1:length(co2.1)])
    dataSham<-dataSham[,sample(1:ncol(dataSham),ncol(dataSham))]
    dataTAC<-cbind(dataTACB1[,(length(co1.1)+1):ncol(dataTACB1)],dataTACB2[,(length(co2.1)+1):ncol(dataTACB2)])
    dataTAC<-dataTAC[,sample(1:ncol(dataTAC),ncol(dataTAC))]
    
    
    colsSham<-rep("#2196F3",ncol(dataSham))
    colsTAC<-rep("#E81E62",ncol(dataTAC))
    data_all<-cbind(dataSham,dataTAC)
    desi_all<-rbind(desiB1[co1.1,],desiB2[co2.1,],desiB1[co1.2,],desiB2[co2.2,])
    cols_all<-c(colsSham,colsTAC)
    
    
    scDE<-scDE[match(tolower(GeneNames(rownames(data_all),k=2)),tolower(GeneNames(as.character(scDE[,1]),k=2)),nomatch=0),]
    cm<-cm[match(tolower(GeneNames(rownames(data_all),k=2)),tolower(GeneNames(cm[,1],k=2)),nomatch=0),]
    pDE<-pDE[match(tolower(GeneNames(rownames(data_all),k=2)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0),]


    sl<-sort.list(as.numeric(as.character(scDE[,2])))
    scDE<-scDE[sl,]
    pDE<-pDE[sl,]
    data_all<-data_all[sl,]
    cm<-cm[sl,]

    heat.vals<-data_all
    rownames(heat.vals)<-GeneNames(rownames(heat.vals),k=2)
    my.dist <- dist(t(heat.vals))
    my.tree <- hclust(my.dist, method = "average")
    my.clusters <- factor(as.character(desi_all$Condition))
    clust.col<-cols_all
    my_palette <- colorRampPalette(c(gg_color_hue(10)[7], "gray90", gg_color_hue(10)[1]))(n = 50)
    gg.smooth<-cbind(Protein=as.character(scDE[,1]),logFC=as.numeric(as.character(scDE[,2])),rightCol=cm[,3],leftCol=cm[,2])

    superheat(heat.vals,scale=F,heat.pal=my_palette,left.label.size = 0.2,left.label.text.size = 2,bottom.label.col=clust.col,
        left.label.col=gg.smooth[,4],yr=as.numeric(gg.smooth[,2]),yr.plot.type="bar",yr.obs.col = gg.smooth[,3],yr.axis.name = "logFC",yr.num.ticks=5)

    gg.smooth[gg.smooth[,4]=="#71D4C2",4]<-"green"
    gg.smooth[gg.smooth[,4]=="#FEE9A4",4]<-"khaki"
    gg.smooth[gg.smooth[,4]=="#BBBBBB",4]<-"gray"
    gg.smooth<-cbind(gg.smooth,Flag=as.character(pDE$QC))
    
    i1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS"),1]
    i2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS"),1]
    i3<-gg.smooth[which(gg.smooth[,4]=="gray" & gg.smooth[,5]=="PASS"),1]

    j<-unique(c(as.character(deKeep[[1]][,1]),as.character(deKeep[[2]][,1])))
    
    m1<-length(intersect(c(i1,i2),j))
    m2<-length(setdiff(j,c(i1,i2)))
    m3<-length(intersect(i3,j))
    m4<-length(setdiff(j,i3))

    mat<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat)<-c("Consistent","Inconsistent")
    rownames(mat)<-c("Common","Non-common")
        
    mm<-match(toupper(GeneNames(gg.smooth[,1],k=2)),as.character(lvefStats[,6]))
    lvefStats1<-lvefStats[mm,]
    mm<-match(toupper(GeneNames(unique(c(as.character(deKeep[[1]][,1]),as.character(deKeep[[2]][,1]))),k=2)),as.character(lvefStats[,6]))
    lvefStats2<-lvefStats[mm,]
    
    ii1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS" | as.numeric(as.character(lvefStats1[,10]))>0.05),1]

    jj<-unique(c(as.character(deKeep[[1]][as.numeric(as.character(lvefStats1[,10]))<=0.05,1]),as.character(deKeep[[2]][as.numeric(as.character(lvefStats1[,10]))<=0.05,1])))

    m1<-length(intersect(c(ii1,ii2),jj))
    m2<-length(setdiff(jj,c(ii1,ii2)))
    m3<-length(intersect(ii3,jj))
    m4<-length(setdiff(jj,ii3))

    mat.lvef<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat.lvef)<-c("Consistent","Inconsistent")
    rownames(mat.lvef)<-c("Common","Non-common")

 return(list(gg.smooth,deKeep,mat,mat.lvef))

}
 

# analysis of mouse myocytes (time-course)
scrna_myocytes_time<-function(scExpr,scDesign,scDE,pDE,lvefStats){
    
    scDE$logFC<- -as.numeric(as.character(scDE$logFC))

    deKeep<-scDE
    deKeep<-deKeep[which(abs(as.numeric(as.character(deKeep[,2])))>1 & as.numeric(as.character(deKeep[,6]))<=0.1),]
    
    pDE<-as.matrix(pDE[-grep("Human-virus",as.character(pDE[,1])),])
    pDE_new<-matrix(0,1,ncol(pDE))
    for(i in 1:nrow(pDE)){
        tt<-unlist(strsplit(GeneNames(as.character(pDE[i,1]),k=2),"_"))
        if(length(tt)>1){
            dd<-t(matrix(rep(pDE[i,],length(tt)),ncol=length(tt)))
            dd[,1]<-tt
            pDE_new<-rbind(pDE_new,dd)
        } else {
            pDE_new<-rbind(pDE_new,pDE[i,])
        }
    }
    pDE<-data.frame(pDE_new[-1,])
    ii<-intersect(tolower(scDE[,1]),tolower(GeneNames(pDE[,1],k=2)))
    scDE<-scDE[match(tolower(scDE[,1]),ii,nomatch=0)>0,]

    uu<-unique(as.character(scDE[,1]))
    scDE2<-matrix(0,1,ncol(scDE))
    for(i in 1:length(uu)){
        d<-as.matrix(scDE[scDE[,1]==uu[i],],ncol=ncol(scDE))
        logfc<-as.numeric(as.character(d[,2]))
        fdr<-as.numeric(as.character(d[,6]))
        if(length(logfc[abs(logfc)>1])>=2 & length(fdr[fdr<=0.1])>=2){
            scDE2<-rbind(scDE2,d)
        }
    }
    scDE<-scDE2[-1,]
    ccde<-colnames(scDE)

    uu<-unique(as.character(scDE[,1]))
    summde<-matrix(0,1,ncol(scDE))
    for(i in 1:length(uu)){
        d<-matrix(scDE[scDE[,1]==uu[i],],ncol=ncol(scDE))
        d<-matrix(c(d[1,1],mean(as.numeric(as.character(d[,2]))),mean(as.numeric(as.character(d[,3]))),mean(as.numeric(as.character(d[,4]))),
                mean(as.numeric(as.character(d[,5]))),mean(as.numeric(as.character(d[,6]))),mean(as.numeric(as.character(d[,7]))),"Sham-TAC","GSE95140_mouse"),nrow=1)
        summde<-rbind(summde,d)
    }
    scDE<-summde[-1,]
    colnames(scDE)<-ccde
    pDE<-pDE[match(tolower(scDE[,1]),tolower(GeneNames(pDE[,1],k=2))),]

    cm<-as.character(pDE[,1])
    col.idx<-rep("#BBBBBB",length(cm))
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2])))]<-"#FEE9A4"
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))<=0.05]<-"#71D4C2"
    col.idx[sign(as.numeric(as.character(pDE[,6])))!=sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))>0.05]<-"white"
    col.idx2<-rep("gray",nrow(scDE))
    col.idx2[as.numeric(as.character(scDE[,6]))<=1e-3]<-"cyan"
    cm<-cbind(cm,col.idx,col.idx2)
    out<-which(cm[,2]=="white")
    cm<-cm[-out,]
    scDE<-scDE[-out,]
    pDE<-pDE[-out,]

    rownames(scExpr)<-scExpr[,1]
    scExpr<-scExpr[,-1]
    aa<-apply(scExpr,2,sum)
    for(i in 1:ncol(scExpr)){
        scExpr[,i]<-1e+6 * scExpr[,i]/aa[i]
    }
    scExpr<-log(scExpr+1,2)
    colnames(scDesign)<-c("SampleID","Condition","Day","Batch","ID")
    sl<-sort.list(scDesign$Condition)
    scDesign<-scDesign[sl,]
    scExpr<-scExpr[,sl]
    scDE<-scDE[match(tolower(rownames(scExpr)),tolower(as.character(scDE[,1])),nomatch=0),]
    cm<-cm[match(tolower(rownames(scExpr)),tolower(GeneNames(cm[,1],k=2)),nomatch=0),]
    pDE<-pDE[match(tolower(rownames(scExpr)),tolower(GeneNames(pDE[,1],k=2)),nomatch=0),]
    scExpr<-scExpr[match(tolower(rownames(scExpr)),tolower(as.character(scDE[,1])),nomatch=0)>0,]

    sl<-sort.list(as.numeric(as.character(scDE[,2])))
    scDE<-scDE[sl,]
    pDE<-pDE[sl,]
    scExpr<-scExpr[sl,]
    cm<-cm[sl,]
    cols<-rep(c("#2196F3","#FF3C3C","#B61D1D","#760B0B"),table(data.frame(as.matrix(scDesign$Day))))

    heat.vals<-scExpr-rowMeans(scExpr)
    my.dist <- dist(t(heat.vals))
    my.tree <- hclust(my.dist, method = "average")
    my.clusters <- factor(as.character(scDesign$Condition))
    clust.col<-cols
    my_palette <- colorRampPalette(c(gg_color_hue(10)[7], "gray90", gg_color_hue(10)[1]))(n = 50)
    gg.smooth<-cbind(Protein=as.character(scDE[,1]),logFC=as.numeric(as.character(scDE[,2])),rightCol=cm[,3],leftCol=cm[,2])

    superheat(heat.vals,scale=F,heat.pal=my_palette,left.label.size = 0.2,left.label.text.size = 1.5,bottom.label.col=clust.col,
        left.label.col=gg.smooth[,4],yr=as.numeric(gg.smooth[,2]),yr.plot.type="bar",yr.obs.col = gg.smooth[,3],yr.axis.name = "logFC",yr.num.ticks=5)

    gg.smooth[gg.smooth[,4]=="#71D4C2",4]<-"green"
    gg.smooth[gg.smooth[,4]=="#FEE9A4",4]<-"khaki"
    gg.smooth[gg.smooth[,4]=="#BBBBBB",4]<-"gray"
    gg.smooth<-cbind(gg.smooth,Flag=as.character(pDE$QC))
           
    i1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS"),1]
    i2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS"),1]
    i3<-gg.smooth[which(gg.smooth[,4]=="gray" & gg.smooth[,5]=="PASS"),1]

    j<-as.character(deKeep[,1])
    
    m1<-length(intersect(c(i1,i2),j))
    m2<-length(setdiff(j,c(i1,i2)))
    m3<-length(intersect(i3,j))
    m4<-length(setdiff(j,i3))

    mat<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat)<-c("Consistent","Inconsistent")
    rownames(mat)<-c("Common","Non-common")
            
    mm<-match(toupper(gg.smooth[,1]),as.character(lvefStats[,6]))
    lvefStats1<-lvefStats[mm,]
    mm<-match(toupper(deKeep[,1]),as.character(lvefStats[,6]))
    lvefStats2<-lvefStats[mm,]
    
    ii1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS" | as.numeric(as.character(lvefStats1[,10]))>0.05),1]

    jj<-as.character(deKeep[as.numeric(as.character(lvefStats2[,10]))<=0.05,1])

    m1<-length(intersect(c(ii1,ii2),jj))
    m2<-length(setdiff(jj,c(ii1,ii2)))
    m3<-length(intersect(ii3,jj))
    m4<-length(setdiff(jj,ii3))

    mat.lvef<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat.lvef)<-c("Consistent","Inconsistent")
    rownames(mat.lvef)<-c("Common","Non-common")

 return(list(gg.smooth,deKeep,mat,mat.lvef))
}

# analysis of human myocytes
scrna_humanMyocytes<-function(scExpr,scDesign,scDE,pDE,lvefStats){
    
    scDE[,2]<- -as.numeric(as.character(scDE[,2]))
    scDE<-scDE[sort.list(as.numeric(as.character(scDE[,2]))),]
    scDE<-scDE[abs(as.numeric(as.character(scDE$logFC)))>1,]

    deKeep<-scDE
    
    
    pDE<-as.matrix(pDE[-grep("Human-virus",as.character(pDE[,1])),])
    pDE_new<-matrix(0,1,ncol(pDE))
    for(i in 1:nrow(pDE)){
        tt<-unlist(strsplit(GeneNames(as.character(pDE[i,1]),k=2),"_"))
        if(length(tt)>1){
            dd<-t(matrix(rep(pDE[i,],length(tt)),ncol=length(tt)))
            dd[,1]<-tt
            pDE_new<-rbind(pDE_new,dd)
        } else {
            pDE_new<-rbind(pDE_new,pDE[i,])
        }
    }
    pDE<-data.frame(pDE_new[-1,])
    mm<-match(tolower(as.character(scDE[,1])),tolower(GeneNames(pDE[,1],k=2)),nomatch=0)
    pDE<-pDE[mm,]
    scDE<-scDE[mm>0,]

    dcm<-as.character(pDE[,1])
    col.idx<-rep("#BBBBBB",length(dcm))
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2])))]<-"#FEE9A4"
    col.idx[sign(as.numeric(as.character(pDE[,6])))==sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))<=0.05]<-"#71D4C2"
    col.idx[sign(as.numeric(as.character(pDE[,6])))!=sign(as.numeric(as.character(scDE[,2]))) & as.numeric(as.character(pDE[,10]))>0.05]<-"white"
    col.idx2<-rep("gray",nrow(scDE))
    col.idx2[as.numeric(as.character(scDE$adj.P.Val))<=1e-3]<-"cyan"
    dcm<-cbind(dcm,col.idx,col.idx2)
    out<-which(dcm[,2]=="white")
    dcm<-dcm[-out,]
    scDE<-scDE[-out,]
    pDE<-pDE[-out,]

    rownames(scExpr)<-scExpr[,1]
    scExpr<-scExpr[,-1]
    aa<-apply(scExpr,2,sum)
    for(i in 1:ncol(scExpr)){
        scExpr[,i]<-1e+6 * scExpr[,i]/aa[i]
    }
    scDesign<-cbind(scDesign[,1:2],Species=rep("Human",nrow(scDesign)))
    ro1<-unique(match(GeneNames(dcm,k=2),rownames(scExpr),nomatch=0))
    co1<-which(scDesign$Condition=="Control")
    co2<-which(scDesign$Condition=="DCM")
    dataControl<-log(scExpr[ro1,co1]+1,2)
    dataDCM<-log(scExpr[ro1,co2]+1,2)
    desi_all<-scDesign[c(co1,co2),]
    pDE<-pDE[match(rownames(dataDCM),GeneNames(pDE[,1],k=2),nomatch=0),]
    scDE<-scDE[match(rownames(dataDCM),as.character(scDE[,1]),nomatch=0),]
    dcm<-dcm[match(rownames(dataDCM),GeneNames(dcm[,1],k=2),nomatch=0),]

    my_palette <- colorRampPalette(c(gg_color_hue(10)[7], "gray90", gg_color_hue(10)[1]))(n = 50)
    aa1<-apply(dataControl,2,median)
    aa2<-apply(dataDCM,2,median)
    dataControl<-dataControl[,sort.list(aa1,decreasing=TRUE)]
    dataDCM<-dataDCM[,sort.list(aa2)]
    data1<-cbind(dataControl,dataDCM)
    desi1<-desi_all[match(colnames(data1),rownames(desi_all)),]

    heat.vals <- data1-rowMeans(data1)
    my.dist <- dist(t(heat.vals))
    my.tree <- hclust(my.dist, method = "average")
    my.clusters <- factor(as.character(desi1[,2]))
    clust.col<-rep("#2196F3",nrow(desi1))
    clust.col[my.clusters=="DCM"]<-"#E81E62"
    gg.smooth<-cbind(Protein=as.character(scDE[,1]),logFC=as.numeric(as.character(scDE[,2])),rightCol=dcm[,3],leftCol=dcm[,2])

    superheat(heat.vals,scale=F,heat.pal=my_palette,left.label.size = 0.2,left.label.text.size = 2,bottom.label.col=clust.col,
        left.label.col=gg.smooth[,4],yr=as.numeric(gg.smooth[,2]),yr.plot.type="bar",yr.obs.col = gg.smooth[,3],yr.axis.name = "logFC",yr.num.ticks=5)

    gg.smooth[gg.smooth[,4]=="#71D4C2",4]<-"green"
    gg.smooth[gg.smooth[,4]=="#FEE9A4",4]<-"khaki"
    gg.smooth[gg.smooth[,4]=="#BBBBBB",4]<-"gray"
    gg.smooth<-cbind(gg.smooth,Flag=as.character(pDE$QC))
                  
    i1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS"),1]
    i2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS"),1]
    i3<-gg.smooth[which(gg.smooth[,4]=="gray" & gg.smooth[,5]=="PASS"),1]

    j<-as.character(deKeep[,1])
           
    m1<-length(intersect(c(i1,i2),j))
    m2<-length(setdiff(j,c(i1,i2)))
    m3<-length(intersect(i3,j))
    m4<-length(setdiff(j,i3))

    mat<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat)<-c("Consistent","Inconsistent")
    rownames(mat)<-c("Common","Non-common")
                   
    mm<-match(toupper(GeneNames(gg.smooth[,1],k=2)),GeneNames(as.character(lvefStats[,6]),k=2))
    lvefStats1<-lvefStats[mm,]
    mm<-match(toupper(GeneNames(deKeep[,1],k=2)),GeneNames(as.character(lvefStats[,6]),k=2))
    lvefStats2<-lvefStats[mm,]
    
    ii1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS" | as.numeric(as.character(lvefStats1[,10]))>0.05),1]

    jj<-as.character(deKeep[as.numeric(as.character(lvefStats2[,10]))<=0.05,1])

    m1<-length(intersect(c(ii1,ii2),jj))
    m2<-length(setdiff(jj,c(ii1,ii2)))
    m3<-length(intersect(ii3,jj))
    m4<-length(setdiff(jj,ii3))

    mat.lvef<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat.lvef)<-c("Consistent","Inconsistent")
    rownames(mat.lvef)<-c("Common","Non-common")

    mm<-match(toupper(gg.smooth[,1]),as.character(lvefStats[,6]))
    lvefStats1<-lvefStats[mm,]
    mm<-match(toupper(deKeep[,1]),as.character(lvefStats[,6]))
    lvefStats2<-lvefStats[mm,]
    
    ii1<-gg.smooth[which(gg.smooth[,4]=="green" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii2<-gg.smooth[which(gg.smooth[,4]=="khaki" & gg.smooth[,5]=="PASS" & as.numeric(as.character(lvefStats1[,10]))<=0.05),1]
    ii3<-gg.smooth[which(gg.smooth[,4]=="gray" | gg.smooth[,5]!="PASS" | as.numeric(as.character(lvefStats1[,10]))>0.05),1]

    jj<-as.character(deKeep[as.numeric(as.character(lvefStats2[,10]))<=0.05,1])

    m1<-length(intersect(c(ii1,ii2),jj))
    m2<-length(setdiff(jj,c(ii1,ii2)))
    m3<-length(intersect(ii3,jj))
    m4<-length(setdiff(jj,ii3))

    mat.lvef<-matrix(c(m1,m2,m3,m4),ncol=2)
    colnames(mat.lvef)<-c("Consistent","Inconsistent")
    rownames(mat.lvef)<-c("Common","Non-common")

 return(list(gg.smooth,deKeep,mat,mat.lvef))
}


# the final prioritisation step
integrated_prioritisation<-function(edges,dina,validated,weight_cut=0.1){
    
    w1<-match(as.character(edges[,1]),GeneNames(as.character(validated)),nomatch=0)
    w2<-match(as.character(edges[,2]),GeneNames(as.character(dina)),nomatch=0)
    Set1<-cbind(edges[,1:3],w1,w2)
    w1<-which(apply(Set1[,4:5],1,function(x) length(x[x>0]))==2)
    Set1<-Set1[w1,]
    w1<-match(as.character(edges[,2]),GeneNames(as.character(validated)),nomatch=0)
    w2<-match(as.character(edges[,1]),GeneNames(as.character(dina)),nomatch=0)
    Set2<-cbind(edges[,1:3],w1,w2)
    w2<-which(apply(Set2[,4:5],1,function(x) length(x[x>0]))==2)
    Set2<-Set2[w2,]
    Set<-rbind(Set1[,1:3],Set2[,1:3])
    Set<-Set[sort.list(as.numeric(as.character(Set[,3])),decreasing=T),]
    Set<-Set[as.numeric(as.character(Set[,3]))>weight_cut,]
    set<-unique(c(as.character(Set[,1]),as.character(Set[,2])))
    set<-intersect(set,GeneNames(validated))
    set<-validated[match(set,GeneNames(validated))]

 return(set)
}
